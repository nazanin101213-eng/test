<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/dashboard.css">
    <title>پنل مدیریت قطعات خودرو</title>
    <style>
        @import 'font/fonts.css';
        *{
             font-family: IranSansX !important;

        }
    </style>
    </head>
<body>
<?php 
include('include/db.php');

// تنظیمات صفحه‌بندی
$records_per_page = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $records_per_page;

// فیلتر نوع کاربر
$type_filter = $_GET['type'] ?? 'all';

// ساخت شرط WHERE
$where = '';
if ($type_filter === 'admin') {
    $where = "WHERE type = 'admin'";
} elseif ($type_filter === 'user') {
    $where = "WHERE type != 'admin'";
}

// شمارش کل کاربران (با فیلتر)
$total_sql = "SELECT COUNT(*) as total FROM user $where";
$total_result = $conn->query($total_sql);
$total_row = $total_result->fetch_assoc();
$total_records = $total_row['total'];
$total_pages = ceil($total_records / $records_per_page);

// کوئری اصلی (با فیلتر و صفحه‌بندی)
$sql = "SELECT * FROM user $where LIMIT $offset, $records_per_page";
$result = $conn->query($sql);

include('include/main_admin.php');
?>

<!-- بقیه HTML شما (از اینجا شروع میشه) -->
<div class="dashboard-container">
    <?php include('include/header_admin.php')?>

    <div class="main-content">
        <header class="top-nav">
            <div style="display: flex; align-items: center;">
                <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                    <svg viewBox="0 0 24 24">
                        <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                    </svg>
                </button>
                <h1 class="page-title">مدیریت کاربران</h1>
            </div>
            <div class="top-nav-actions">
                <div class="search-box">
                    <input type="text" class="search-input" placeholder="جستجوی تیکت، کاربر، کد...">
                    <svg class="search-icon" viewBox="0 0 24 24">
                        <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                    </svg>
                </div>
                <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                    <svg class="notification-icon" viewBox="0 0 24 24">
                        <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                    </svg>
                    <div class="notification-badge">۵</div>
                </button>
            </div>
        </header>

        <main class="dashboard-content">

            <!-- فیلترها و دکمه‌ها -->
            <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
                <div class="flex space-x-2 space-x-reverse">
                    <!-- همه کاربران -->
                    <a href="?type=all&page=1" 
                       class="px-4 py-2 rounded-full text-sm font-medium flex items-center transition-all shadow-sm
                       <?= $type_filter === 'all' ? 'bg-[#1F7D3B] text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"></path>
                        </svg>
                        همه کاربران
                    </a>

                    <!-- فقط ادمین‌ها -->
                    <a href="?type=admin&page=1" 
                       class="px-4 py-2 rounded-full text-sm font-medium flex items-center transition-all shadow-sm
                       <?= $type_filter === 'admin' ? 'bg-[#1F7D3B] text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        فقط ادمین‌ها
                    </a>

                    <!-- کاربران عادی -->
                    <a href="?type=user&page=1" 
                       class="px-4 py-2 rounded-full text-sm font-medium flex items-center transition-all shadow-sm
                       <?= $type_filter === 'user' ? 'bg-[#1F7D3B] text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                        کاربران عادی
                    </a>
                </div>

                <!-- جستجو در موبایل -->
                <div class="md:hidden relative w-full">
                    <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                        <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </div>
                    <input type="text" class="bg-gray-100 border-0 rounded-lg pr-10 pl-4 py-2 text-sm focus:ring-2 focus:ring-[#1F7D3B] focus:bg-white transition-all w-full" placeholder="جستجو کاربر...">
                </div>

                <!-- افزودن کاربر -->
                <a href="add_admin.php" class="bg-[#1F7D3B] hover:bg-[#1a6a32] text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center transition-all shadow-sm">
                    <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                    </svg>
                    افزودن کاربر جدید
                </a>
            </div>

            <!-- جدول کاربران -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden fade-in">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">نام کامل</th>
                                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">نام کاربری</th>
                                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">شماره تماس</th>
                                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">نقش کاربر</th>
                                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">آدرس</th>
                                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">وضعیت</th>
                                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">عملیات</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php 
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                            ?>
                            <tr class="table-row-hover transition-colors">
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900"><?= htmlspecialchars($row['fullName']) ?></div>
                                    
                                    <div class="text-sm text-gray-500"><?= htmlspecialchars($row['email']) ?></div>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500"><?= htmlspecialchars($row['username']) ?></td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500"><?= htmlspecialchars($row['phone']) ?></td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?= match($row['type']) {  'admin'  => 'bg-purple-100 text-purple-800', 'supperadmin' => 'bg-yellow-100 text-yellow-800', default  => 'bg-blue-100 text-blue-800', } ?>">
                                        
                                        <?= match($row['type']) { 'admin'  => 'ادمین', 'supperadmin' => 'سوپر ادمین', default  => 'عادی', } ?>
                                    </span>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500"></td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?= $row['active'] == '1' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                        <?= $row['active'] == '1' ? 'فعال' : 'غیرفعال' ?>
                                    </span>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium">
                                    <!-- ویرایش -->
                                    <a href="edit_admin.php?id=<?= $row['user_id']?>" class="text-green-700 hover:text-green-800 inline-block ml-3" title="ویرایش">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                    </a>
                                    <!-- حذف -->
                                    <a href="delete_admin.php?id=<?= $row['user_id']?>" class="text-red-600 hover:text-red-800 inline-block ml-3" onclick="return confirm('آیا از حذف مطمئن هستید؟')" title="حذف">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                    </a>
                                    <!-- کامنت -->
                                    <a href="Show_comment.php?id=<?= $row['user_id']?>" class="text-green-700 hover:text-green-800 inline-block ml-3" title="کامنت">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>
                                    </a>
                                    <!-- پشتیبانی -->
                                    <a href="support.php?id=<?= $row['user_id']?>" class="text-green-700 hover:text-green-800 inline-block ml-3" title="پشتیبانی">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m7.414-9.828V6a3 3 0 00-3-3H7a3 3 0 00-3 3v7a3 3 0 003 3h2v4l4-4h3a3 3 0 003-3V8z"></path></svg>
                                    </a>
                                </td>
                            </tr>
                            <?php
                                }
                            } else {
                                echo '<tr><td colspan="6" class="text-center py-4 text-gray-500">هیچ کاربری یافت نشد.</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- صفحه‌بندی داینامیک -->
                <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                    <div class="flex-1 flex justify-between items-center sm:hidden">
                        <?php if ($page > 1): ?>
                            <a href="?type=<?= $type_filter ?>&page=<?= $page - 1 ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">قبلی</a>
                        <?php else: ?>
                            <span class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white opacity-50 cursor-not-allowed">قبلی</span>
                        <?php endif; ?>

                        <?php if ($page < $total_pages): ?>
                            <a href="?type=<?= $type_filter ?>&page=<?= $page + 1 ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">بعدی</a>
                        <?php else: ?>
                            <span class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white opacity-50 cursor-not-allowed">بعدی</span>
                        <?php endif; ?>
                    </div>

                    <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                        <div>
                            <p class="text-sm text-gray-700">
                                نمایش
                                <span class="font-medium"><?= $offset + 1 ?></span>
                                تا
                                <span class="font-medium"><?= min($offset + $records_per_page, $total_records) ?></span>
                                از
                                <span class="font-medium"><?= $total_records ?></span>
                                نتیجه
                            </p>
                        </div>
                        <div>
                            <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                                <!-- قبلی -->
                                <?php if ($page > 1): ?>
                                    <a href="?type=<?= $type_filter ?>&page=<?= $page - 1 ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                                    </a>
                                <?php endif; ?>

                                <!-- صفحات -->
                                <?php
                                $start = max(1, $page - 2);
                                $end = min($total_pages, $page + 2);

                                if ($start > 1):
                                    echo '<a href="?type=' . $type_filter . '&page=1" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium">1</a>';
                                    if ($start > 2) echo '<span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-400">...</span>';
                                endif;

                                for ($i = $start; $i <= $end; $i++):
                                    $link = "?type=$type_filter&page=$i";
                                    if ($i == $page):
                                        echo "<span class=\"z-10 bg-[#1F7D3B] border-[#1F7D3B] text-white relative inline-flex items-center px-4 py-2 border text-sm font-medium\">$i</span>";
                                    else:
                                        echo "<a href=\"$link\" class=\"bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium\">$i</a>";
                                    endif;
                                endfor;

                                if ($end < $total_pages):
                                    if ($end < $total_pages - 1) echo '<span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-400">...</span>';
                                    echo '<a href="?type=' . $type_filter . '&page=' . $total_pages . '" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium">' . $total_pages . '</a>';
                                endif;
                                ?>

                                <!-- بعدی -->
                                <?php if ($page < $total_pages): ?>
                                    <a href="?type=<?= $type_filter ?>&page=<?= $page + 1 ?>" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                                    </a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include('include/footer_admin.php') ?>
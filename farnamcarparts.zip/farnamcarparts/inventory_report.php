<?php include('include/main_admin.php')?>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<style>
  .part-img { object-fit: cover; }
  .table-shadow { box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04); }
  .accent-bg { 
    background: 
      linear-gradient(135deg, rgba(242, 194, 42, 0.06) 0%, rgba(31, 125, 59, 0.02) 100%),
      url("data:image/svg+xml,%3Csvg width='120' height='120' viewBox='0 0 120 120' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' stroke='%23F2C22A' stroke-width='1.5' stroke-opacity='0.04'%3E%3Cpath d='M60 15a45 45 0 0 1 0 90 45 45 0 0 1 0-90zm0 75a30 30 0 0 0 0-60 30 30 0 0 0 0 60z'/%3E%3Ccircle cx='60' cy='60' r='15'/%3E%3C/g%3E%3C/svg%3E") repeat;
  }
</style>
  <!-- Mobile Sidebar Overlay -->
    <div class="sidebar-overlay" onclick="closeMobileMenu()"></div>
<div class="dashboard-container" dir="rtl">
    <?php include('include/header_admin.php')?>
    <div class="main-content">
       <header class="top-nav">
                <div style="display: flex; align-items: center;">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                        </svg>
                    </button>
                    <h1 class="page-title">موجودی انبار</h1>
                </div>
                <div class="top-nav-actions">
                    <div class="search-box">
                        <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                        <svg class="search-icon" viewBox="0 0 24 24">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                        </svg>
                    </div>
                    <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                        <svg class="notification-icon" viewBox="0 0 24 24">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                        <div class="notification-badge">۵</div>
                    </button>
                </div>
            </header>

        <main class="dashboard-content p-4 md:p-6 lg:p-8 accent-bg min-h-screen">
            <div class="mx-auto">

                <!-- Desktop Table View -->
                <div class="hidden lg:block bg-white rounded-2xl overflow-hidden table-shadow mb-8">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">تصویر</th>
                                    <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">نام قطعه</th>
                                    <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">توضیحات</th>
                                    <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">قیمت</th>
                                    <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">دسته‌بندی</th>
                                    <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">کد قطعه</th>
                                    <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">موجودی</th>
                                    <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">وضعیت</th>
                                    <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">عملیات</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <!-- Sample Row 1 - Available -->
                                <tr class="hover:bg-gray-50 transition duration-150">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <img src="https://via.placeholder.com/60x60?text=فیلتر" alt="فیلتر روغن" class="w-14 h-14 rounded-lg part-img shadow-sm">
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">فیلتر روغن موتور</td>
                                    <td class="px-6 py-4 text-sm text-gray-600 max-w-xs truncate">فیلتر اصلی با استاندارد OEM، سازگار با مدل‌های 1398+</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">285,000 تومان</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">موتور</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 font-mono">OIL-FT-882</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-bold">142</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">موجود</span>
                                    </td>
                                    <td class="px-4 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="edit_product.php" class="text-[#1F7D3B] hover:text-[#1a6a32] ml-3 transition-colors inline-block">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z">
                                        </path>
                                    </svg>
                                </a>

                                <a href="#" class="text-red-600 hover:text-red-900 transition-colors inline-block">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                         d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                        </path>
                                    </svg>
                                </a>
                        </td>
                                </tr>

                              
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Mobile & Tablet Card View -->
                <div class="lg:hidden space-y-4 mb-8">
                    <!-- Card 1 - Available -->
                    <div class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition duration-200">
                        <div class="p-4">
                            <div class="flex items-start justify-between mb-3">
                                <img src="https://via.placeholder.com/80x80?text=فیلتر" alt="فیلتر روغن" class="w-16 h-16 rounded-lg part-img shadow-sm flex-shrink-0">
                                <div class="mr-3 flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900">فیلتر روغن موتور</h3>
                                    <p class="text-sm text-gray-600 mt-1">کد: <span class="font-mono">OIL-FT-882</span></p>
                                </div>
                            </div>
                            <p class="text-sm text-gray-600 mb-3 line-clamp-2">فیلتر اصلی با استاندارد OEM، سازگار با مدل‌های 1398+</p>
                            <div class="flex items-center justify-between mb-3">
                                <span class="text-lg font-bold text-gray-900">285,000 تومان</span>
                                <span class="px-3 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">موتور</span>
                            </div>
                            <div class="flex items-center justify-between mb-3">
                                <span class="text-sm font-bold text-gray-900">موجودی: <span class="text-green-600">142</span></span>
                                <span class="px-3 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">موجود</span>
                            </div>
                            <div class="flex justify-end space-x-2 space-x-reverse">
                                <a href="edit_product.php" class="text-[#1F7D3B] hover:text-[#1a6a32] ml-3 transition-colors inline-block">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z">
                                        </path>
                                    </svg>
                                </a>

                                <a href="#" class="text-red-600 hover:text-red-900 transition-colors inline-block">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                         d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                        </path>
                                    </svg>
                                </a>
                                </div>
                        </div>
                    </div>

                   
                </div>

                <!-- Primary Action Buttons - BELOW the inventory -->
                <div class="flex flex-col sm:flex-row gap-3 justify-center lg:justify-end">
                    <!-- Add New Part - Green -->
                    <a href="add_product.php" class="inline-flex items-center justify-center px-6 py-3 bg-green-700 hover:bg-green-800 text-white font-medium rounded-xl shadow-lg transition duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                        <svg class="w-5 h-5 ml-2 transform rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                        افزودن قطعه جدید
                    </a>

                    <!-- Inventory Report - Yellow (Optional) -->
                    <!-- <a href="inventory_report.php" class="inline-flex items-center justify-center px-6 py-3 bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-medium rounded-xl shadow-lg transition duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-400">
                        <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                        گزارش موجودی
                    </a> -->
                </div>

            </div>
        </main>
    </div>
</div>
<?php include('include/footer_admin.php')?>

<!-- Delete Confirmation -->
<script>
    function confirmDelete(partId) {
        if (confirm('آیا از حذف این قطعه اطمینان دارید؟ این عمل قابل بازگشت نیست.')) {
            // In real app: send AJAX or redirect to delete_part.php?id=...
            alert('قطعه با شناسه ' + partId + ' حذف شد.');
        }
    }
</script>
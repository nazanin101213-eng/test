-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 30, 2025 at 10:27 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `farnamcarpart`
--
CREATE DATABASE IF NOT EXISTS `farnamcarpart` DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci;
USE `farnamcarpart`;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
CREATE TABLE IF NOT EXISTS `carts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

DROP TABLE IF EXISTS `cart_items`;
CREATE TABLE IF NOT EXISTS `cart_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cart_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `price_at_time` decimal(10,2) NOT NULL,
  `subtotal` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_id` (`cart_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'pride'),
(2, '206'),
(3, '405');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `comment_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `comment` text COLLATE utf8mb3_persian_ci NOT NULL,
  `is_active` tinyint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `answer` text COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `address_id` int NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pyment_status` varchar(150) COLLATE utf8mb3_persian_ci NOT NULL,
  `pyment_date` datetime NOT NULL,
  `travsaction_id` int NOT NULL,
  `order_status` enum('pending','shilpped','delivered','returned') COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders_items`
--

DROP TABLE IF EXISTS `orders_items`;
CREATE TABLE IF NOT EXISTS `orders_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `price` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(150) COLLATE utf8mb3_persian_ci NOT NULL,
  `description` text COLLATE utf8mb3_persian_ci NOT NULL,
  `stock` int NOT NULL,
  `product_image` int NOT NULL,
  `category_id` int NOT NULL,
  `sky` varchar(150) COLLATE utf8mb3_persian_ci NOT NULL,
  `min_stock` int NOT NULL,
  `purchas_price` int NOT NULL,
  `final_price` int NOT NULL,
  `supplier_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL,
  `is_amazing` tinyint NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `category_id` (`category_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_discount`
--

DROP TABLE IF EXISTS `product_discount`;
CREATE TABLE IF NOT EXISTS `product_discount` (
  `product_discount_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `discount_type` enum('درصدی','مبلغ ثابت') COLLATE utf8mb3_persian_ci NOT NULL,
  `discount_value` int NOT NULL,
  `discount_price` int NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `is_active` tinyint NOT NULL,
  `craeted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`product_discount_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `supplier_id` int NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb3_persian_ci NOT NULL,
  `company_name` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `address` text COLLATE utf8mb3_persian_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE IF NOT EXISTS `tickets` (
  `tickt_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title_ticket` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `text_ticket` text COLLATE utf8mb3_persian_ci NOT NULL,
  `pro_image` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `answer` text COLLATE utf8mb3_persian_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tickt_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `t_address`
--

DROP TABLE IF EXISTS `t_address`;
CREATE TABLE IF NOT EXISTS `t_address` (
  `address_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `province` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `Postal_code` int NOT NULL,
  `phone` int NOT NULL,
  `recipient_name` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `address` text COLLATE utf8mb3_persian_ci NOT NULL,
  PRIMARY KEY (`address_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `fullName` varchar(150) COLLATE utf8mb3_persian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb3_persian_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb3_persian_ci NOT NULL,
  `type` enum('admin','public','supperadmin') CHARACTER SET utf8mb3 COLLATE utf8mb3_persian_ci NOT NULL,
  `active` tinyint NOT NULL,
  `pass` varchar(50) COLLATE utf8mb3_persian_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `fullName`, `email`, `phone`, `type`, `active`, `pass`, `created_at`) VALUES
(1, 'mahdi87', 'مهدی احمدی', 'mahdi@gamil.com', '09139704786', 'public', 0, 'mahdi86', '2025-10-30 12:35:13'),
(2, 'admin', 'سارا امیری', 'sara@gamil.com', '09139704546', 'admin', 1, 'admin1', '2025-10-30 12:35:13'),
(3, 'supperAdmin', 'حمید رضا خوشنام', '', '09131521082', 'supperadmin', 1, 'adminhamid', '2025-10-30 13:00:06'),
(4, 'adminHamid', 'حمید رضا خوشنام', 'hamidreza@gmail.com', '09131521082', 'supperadmin', 1, '$2y$10$BPqrOfXZd6SygWbZsZEa2utBGZR2/.Ex39bUBaTuazj', '2025-10-30 13:48:56'),
(5, 'saraamiri', 'سارا امیری', 'sara@gmail.com', '09162163720', 'admin', 1, '$2y$10$//uzgV4AMvsOWDpp2fnCPOoV0ym94.SSZKHhuv.R.9R', '2025-10-30 13:52:10');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

DROP TABLE IF EXISTS `wishlist`;
CREATE TABLE IF NOT EXISTS `wishlist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_persian_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php include('include/main_admin.php')?>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<style>
  .accent-bg {
    background: 
      linear-gradient(135deg, rgba(242, 194, 42, 0.05) 0%, rgba(31, 125, 59, 0.02) 100%),
      url("data:image/svg+xml,%3Csvg width='120' height='120' viewBox='0 0 120 120' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' stroke='%23F2C22A' stroke-width='1.5' stroke-opacity='0.04'%3E%3Cpath d='M60 15a45 45 0 0 1 0 90 45 45 0 0 1 0-90zm0 75a30 30 0 0 0 0-60 30 30 0 0 0 0 60z'/%3E%3Ccircle cx='60' cy='60' r='15'/%3E%3C/g%3E%3C/svg%3E") repeat;
  }
  .part-img-preview { object-fit: cover; }
</style>
  <!-- Mobile Sidebar Overlay -->
    <div class="sidebar-overlay" onclick="closeMobileMenu()"></div>
<div class="dashboard-container" dir="rtl">
    <?php include('include/header_admin.php')?>
    <div class="main-content">
        <header class="top-nav">
                <div style="display: flex; align-items: center;">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                        </svg>
                    </button>
                    <h1 class="page-title">افزودن قطعه جدید</h1>
                </div>
                <div class="top-nav-actions">
                    <div class="search-box">
                        <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                        <svg class="search-icon" viewBox="0 0 24 24">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                        </svg>
                    </div>
                    <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                        <svg class="notification-icon" viewBox="0 0 24 24">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                        <div class="notification-badge">۵</div>
                    </button>
                </div>
            </header>
        <main class="dashboard-content p-4 md:p-6 lg:p-8 accent-bg min-h-screen">
            <div class="max-w-2xl mx-auto">
                <!-- Central Form Card -->
                <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
                    <div class="p-6 md:p-8 lg:p-10">
                        <h2 class="text-xl md:text-2xl font-bold text-gray-900 mb-8 text-center">افزودن قطعه جدید</h2>

                        <form id="addPartForm" class="space-y-6" action="process_add_part.php" method="POST" enctype="multipart/form-data" novalidate>
                            <!-- Part Name -->
                            <div>
                                <label for="part_name" class="block text-sm font-medium text-gray-700 mb-2">نام قطعه</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                        <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m2 0a2 2 0 100-4H7a2 2 0 100 4z"/>
                                        </svg>
                                    </div>
                                    <input type="text" id="part_name" name="part_name" required
                                           class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition duration-200 text-base"
                                           placeholder="مثال: بلبرینگ چرخ جلو">
                                </div>
                            </div>

                            <!-- Description -->
                            <div>
                                <label for="description" class="block text-sm font-medium text-gray-700 mb-2">توضیحات</label>
                                <div class="relative">
                                    <div class="absolute top-3 right-0 pr-3 flex items-center pointer-events-none">
                                        <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                                        </svg>
                                    </div>
                                    <textarea id="description" name="description" rows="3" required
                                              class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition duration-200 text-base resize-none"
                                              placeholder="توضیحات کامل قطعه، سازگاری، ویژگی‌ها..."></textarea>
                                </div>
                            </div>

                            <!-- Price -->
                            <div>
                                <label for="price" class="block text-sm font-medium text-gray-700 mb-2">قیمت (تومان)</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                        <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"/>
                                        </svg>
                                    </div>
                                    <input type="text" id="price" name="price" required inputmode="numeric" pattern="[0-9]+"
                                           class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition duration-200 text-base"
                                           placeholder="285000">
                                </div>
                                <p class="mt-1 text-xs text-gray-500">فقط عدد وارد کنید (بدون کاما یا تومان)</p>
                            </div>

                            <!-- Stock -->
                             <div>
                                <label for="description" class="block text-sm font-medium text-gray-700 mb-2">موجودی</label>
                                <div class="relative">
                                    <div class="absolute top-3 right-0 pr-3 flex items-center pointer-events-none">
                                        <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                        </svg>
                                    </div>
                                    <input type="text" id="price" name="price" required inputmode="numeric" pattern="[0-9]+"
                                           class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition duration-200 text-base"
                                           placeholder="10">
                                </div>
                                <p class="mt-1 text-xs text-gray-500">فقط عدد وارد کنید (بدون کاما)</p>
                            </div>

                            <!-- Category -->
                            <div>
                                <label for="category" class="block text-sm font-medium text-gray-700 mb-2">نوع دسته‌بندی</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                        <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7h18M3 12h18M3 17h18"/>
                                        </svg>
                                    </div>
                                    <select id="category" name="category" required
                                            class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition duration-200 text-base">
                                        <option value="" disabled selected>انتخاب کنید</option>
                                        <option value="motor">پراید</option>
                                        <option value="brake">206</option>
                                        <option value="ignition">405</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Part Code -->
                            <div>
                                <label for="part_code" class="block text-sm font-medium text-gray-700 mb-2">کد قطعه</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                        <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                        </svg>
                                    </div>
                                    <input type="text" id="part_code" name="part_code" required
                                           class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition duration-200 text-base font-mono"
                                           placeholder="OIL-FT-882">
                                </div>
                            </div>

                            <!-- Image Upload -->
                            <div>
                                <label for="part_image" class="block text-sm font-medium text-gray-700 mb-2">عکس قطعه</label>
                                <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-xl hover:border-green-400 transition duration-200">
                                    <div class="space-y-1 text-center">
                                        <div id="preview-container" class="hidden mb-3">
                                            <img id="image-preview" src="" alt="پیش‌نمایش" class="mx-auto h-32 w-32 rounded-lg part-img-preview shadow-md">
                                        </div>
                                        <svg id="upload-icon" class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        <div class="flex text-sm text-gray-600 justify-center">
                                            <label for="part_image" class="relative cursor-pointer bg-white rounded-md font-medium text-green-600 hover:text-green-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-green-500">
                                                <span>آپلود فایل</span>
                                                <input id="part_image" name="part_image" type="file" accept="image/*" required class="sr-only">
                                            </label>
                                            <p class="pr-1">یا بکشید و رها کنید</p>
                                        </div>
                                        <p class="text-xs text-gray-500">PNG, JPG, GIF تا 2MB</p>
                                    </div>
                                </div>
                            </div>

                            <!-- Action Buttons -->
                            <div class="flex flex-col sm:flex-row gap-3 pt-4">
                                <!-- Save Part - Green -->
                                <button type="submit"
                                        class="flex-1 flex justify-center items-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-base font-medium text-white bg-green-700 hover:bg-green-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-200">
                                    <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                                    </svg>
                                    ذخیره قطعه
                                </button>

                                <!-- Reset - Gray -->
                                <button type="reset"
                                        class="flex-1 flex justify-center items-center py-3 px-4 border border-gray-300 rounded-xl shadow-sm text-base font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-200">
                                    <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                                    </svg>
                                    بازنشانی
                                </button>
                            </div>

                            <!-- Security/Info Note -->
                            <div class="mt-6 flex items-start text-xs text-gray-500">
                                <svg class="h-5 w-5 text-green-600 flex-shrink-0 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                          d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                                </svg>
                                <p>اطلاعات قطعه با رمزنگاری AES-256 ذخیره شده و فقط مدیران مجاز دسترسی دارند.</p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php include('include/footer_admin.php')?>

<!-- Client-side Validation & Image Preview -->
<script>
    // Image Preview
    document.getElementById('part_image').addEventListener('change', function(e) {
        const file = e.target.files[0];
        const preview = document.getElementById('image-preview');
        const container = document.getElementById('preview-container');
        const icon = document.getElementById('upload-icon');

        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                container.classList.remove('hidden');
                icon.classList.add('hidden');
            };
            reader.readAsDataURL(file);
        } else {
            container.classList.add('hidden');
            icon.classList.remove('hidden');
        }
    });

    // Form Validation
    document.getElementById('addPartForm').addEventListener('submit', function(e) {
        const price = document.getElementById('price').value;
        const image = document.getElementById('part_image').files[0];

        // Validate price is number
        if (!/^\d+$/.test(price)) {
            e.preventDefault();
            alert('لطفاً قیمت را فقط با اعداد وارد کنید.');
            return;
        }

        // Validate image size (2MB)
        if (image && image.size > 2 * 1024 * 1024) {
            e.preventDefault();
            alert('حجم عکس نباید بیشتر از 2 مگابایت باشد.');
            return;
        }

        // Validate image type
        if (image && !['image/jpeg', 'image/jpg', 'image/png', 'image/gif'].includes(image.type)) {
            e.preventDefault();
            alert('فقط فایل‌های JPG, PNG یا GIF مجاز هستند.');
            return;
        }
    });
</script>
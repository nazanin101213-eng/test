<?php include('include/main_admin.php')?>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<!-- Mobile Sidebar Overlay -->

<div class="sidebar-overlay" onclick="closeMobileMenu()"></div>

<div class="dashboard-container">
    <?php include('include/header_admin.php')?>

    <div class="main-content">
       <header class="top-nav">
                <div style="display: flex; align-items: center;">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                        </svg>
                    </button>
                    <h1 class="page-title">ویرایش تخفیف قطعه</h1>
                </div>
                <div class="top-nav-actions">
                    <div class="search-box">
                        <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                        <svg class="search-icon" viewBox="0 0 24 24">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                        </svg>
                    </div>
                    <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                        <svg class="notification-icon" viewBox="0 0 24 24">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                        <div class="notification-badge">۵</div>
                    </button>
                </div>
            </header>

        <main class="dashboard-content rtl bg-gradient-to-br from-yellow-50/30 via-white to-slate-50/50 min-h-screen">
    <!-- Page Container -->
    <div class="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8">
        
        

        <!-- Form Card -->
        <form id="discountForm" class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="p-6 sm:p-8 space-y-8">
                
                <!-- Product Details (Read-only) -->
                <div class="border-b border-gray-200 pb-6">
                    <h2 class="text-lg font-semibold text-gray-800 mb-4">جزئیات محصول</h2>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">شناسه</label>
                            <input type="text" value="12457" readonly class="w-full px-4 py-2.5 bg-gray-50 border border-gray-300 rounded-lg text-gray-600 text-sm cursor-not-allowed">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">کد محصول</label>
                            <input type="text" value="SP-2025-789" readonly class="w-full px-4 py-2.5 bg-gray-50 border border-gray-300 rounded-lg text-gray-600 text-sm cursor-not-allowed">
                        </div>
                        <div class="sm:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1">نام محصول</label>
                            <input type="text" value="لنت ترمز جلو تویوتا کمری 2023" readonly class="w-full px-4 py-2.5 bg-gray-50 border border-gray-300 rounded-lg text-gray-600 text-sm cursor-not-allowed">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">نوع محصول</label>
                            <input type="text" value="لنت ترمز" readonly class="w-full px-4 py-2.5 bg-gray-50 border border-gray-300 rounded-lg text-gray-600 text-sm cursor-not-allowed">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">قیمت</label>
                            <input type="text" value="۱,۲۵۰,۰۰۰ تومان" readonly class="w-full px-4 py-2.5 bg-gray-50 border border-gray-300 rounded-lg text-gray-600 text-sm cursor-not-allowed">
                        </div>
                    </div>
                </div>

                <!-- Discount Settings -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 mb-4">تنظیمات تخفیف</h2>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        
                        <!-- Discount Type -->
                        <div>
                            <label for="discount_type" class="block text-sm font-medium text-gray-700 mb-1">نوع تخفیف <span class="text-red-500">*</span></label>
                            <select id="discount_type" name="discount_type" required class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1F7D3B] focus:border-[#1F7D3B] transition">
                                <option value="">انتخاب کنید</option>
                                <option value="percent" selected>درصدی</option>
                                <option value="fixed">مقداری ثابت</option>
                            </select>
                        </div>

                        <!-- Discount Value -->
                        <div>
                            <label for="discount_value" class="block text-sm font-medium text-gray-700 mb-1">مقدار تخفیف <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <input type="number" id="discount_value" name="discount_value" value="15" min="0" max="100" step="0.01" required 
                                       class="w-full px-4 py-2.5 pe-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1F7D3B] focus:border-[#1F7D3B] transition">
                                <span id="discount_suffix" class="absolute start-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">%</span>
                            </div>
                            <p class="mt-1 text-xs text-gray-500">برای درصد: 1-100، برای مبلغ: حداکثر قیمت محصول</p>
                        </div>

                        <!-- Status Toggle -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">وضعیت <span class="text-red-500">*</span></label>
                            <div class="flex items-center space-x-3 rtl:space-x-reverse">
                                <button type="button" id="statusToggle" class="relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-[#1F7D3B] focus:ring-offset-2" 
                                        role="switch" aria-checked="true">
                                    <span class="inline-block h-4 w-4 transform rounded-full bg-white transition translate-x-5"></span>
                                </button>
                                <span id="statusLabel" class="text-sm font-medium text-green-700">فعال</span>
                                <input type="hidden" name="status" id="statusInput" value="1">
                            </div>
                        </div>

                        <!-- Start Date -->
                        <div>
                            <label for="start_date" class="block text-sm font-medium text-gray-700 mb-1">شروع <span class="text-red-500">*</span></label>
                            <input type="date" id="start_date" name="start_date" value="2025-11-01" required 
                                   class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1F7D3B] focus:border-[#1F7D3B] transition">
                        </div>

                        <!-- End Date -->
                        <div>
                            <label for="end_date" class="block text-sm font-medium text-gray-700 mb-1">پایان <span class="text-red-500">*</span></label>
                            <input type="date" id="end_date" name="end_date" value="2025-12-01" required 
                                   class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1F7D3B] focus:border-[#1F7D3B] transition">
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="flex flex-col sm:flex-row gap-3 pt-6 border-t border-gray-200">
                    <button type="submit" 
                            class="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#1F7D3B] hover:bg-[#1a6a34] text-white font-medium rounded-lg shadow-md transition-all hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-[#1F7D3B] focus:ring-offset-2">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                        ذخیره تغییرات
                    </button>
                    <button type="button" id="resetBtn"
                            class="inline-flex items-center justify-center gap-2 px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium rounded-lg shadow-md transition-all hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                        </svg>
                        بازنشانی
                    </button>
                </div>
            </div>
        </form>

        <!-- Validation Messages -->
        <div id="errorMessages" class="mt-4 hidden"></div>
    </div>
</main>

<style>
    /* Custom Toggle Switch */
    #statusToggle {
        background-color: #e5e7eb;
    }
    #statusToggle[aria-checked="true"] {
        background-color: #1F7D3B;
    }
    #statusToggle .translate-x-5 {
        transform: translateX(1.25rem);
    }
    #statusToggle[aria-checked="false"] .translate-x-5 {
        transform: translateX(0.25rem);
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.getElementById('discountForm');
        const discountType = document.getElementById('discount_type');
        const discountValue = document.getElementById('discount_value');
        const discountSuffix = document.getElementById('discount_suffix');
        const statusToggle = document.getElementById('statusToggle');
        const statusLabel = document.getElementById('statusLabel');
        const statusInput = document.getElementById('statusInput');
        const startDate = document.getElementById('start_date');
        const endDate = document.getElementById('end_date');
        const errorMessages = document.getElementById('errorMessages');
        const resetBtn = document.getElementById('resetBtn');

        // Update discount suffix based on type
        discountType.addEventListener('change', function () {
            discountSuffix.textContent = this.value === 'percent' ? '%' : 'تومان';
            discountValue.max = this.value === 'percent' ? '100' : '1250000';
            discountValue.placeholder = this.value === 'percent' ? 'مثلاً 15' : 'مثلاً 150000';
        });

        // Toggle switch
        statusToggle.addEventListener('click', function () {
            const isActive = this.getAttribute('aria-checked') === 'true';
            this.setAttribute('aria-checked', !isActive);
            statusLabel.textContent = !isActive ? 'فعال' : 'غیرفعال';
            statusLabel.className = !isActive ? 'text-sm font-medium text-green-700' : 'text-sm font-medium text-red-700';
            statusInput.value = !isActive ? '1' : '0';
        });

        // Form validation
        form.addEventListener('submit', function (e) {
            errorMessages.classList.add('hidden');
            errorMessages.innerHTML = '';
            let errors = [];

            // Required fields
            if (!discountType.value) errors.push('نوع تخفیف الزامی است.');
            if (!discountValue.value || discountValue.value <= 0) errors.push('مقدار تخفیف باید بیشتر از صفر باشد.');

            // Date validation
            if (startDate.value && endDate.value && new Date(startDate.value) >= new Date(endDate.value)) {
                errors.push('تاریخ پایان باید بعد از تاریخ شروع باشد.');
            }

            if (errors.length > 0) {
                e.preventDefault();
                errorMessages.classList.remove('hidden');
                errorMessages.className = 'mt-4 p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm';
                errorMessages.innerHTML = '<ul class="list-disc list-inside space-y-1">' + 
                    errors.map(err => `<li>${err}</li>`).join('') + '</ul>';
            }
        });

        // Reset button
        resetBtn.addEventListener('click', function () {
            form.reset();
            discountType.value = 'percent';
            discountValue.value = '15';
            discountSuffix.textContent = '%';
            startDate.value = '2025-11-01';
            endDate.value = '2025-12-01';
            statusToggle.setAttribute('aria-checked', 'true');
            statusLabel.textContent = 'فعال';
            statusLabel.className = 'text-sm font-medium text-green-700';
            statusInput.value = '1';
            errorMessages.classList.add('hidden');
        });

        // Initialize suffix
        discountSuffix.textContent = discountType.value === 'percent' ? '%' : 'تومان';
    });
</script>
    </div>
</div>

<?php include('include/footer_admin.php')?>

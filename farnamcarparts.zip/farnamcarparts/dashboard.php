<?php include('include/main_admin.php')?>


    <!-- Mobile Sidebar Overlay -->
    <div class="sidebar-overlay" onclick="closeMobileMenu()"></div>
    
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include('include/header_admin.php')?>

        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navigation -->
            <header class="top-nav">
                <div style="display: flex; align-items: center;">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                        </svg>
                    </button>
                    <h1 class="page-title">داشبورد قطعات خودرو</h1>
                </div>
                <div class="top-nav-actions">
                    <div class="search-box">
                        <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                        <svg class="search-icon" viewBox="0 0 24 24">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                        </svg>
                    </div>
                    <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                        <svg class="notification-icon" viewBox="0 0 24 24">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                        <div class="notification-badge">۵</div>
                    </button>
                </div>
            </header>
            
            <!-- Dashboard Content -->
            <main class="dashboard-content">
                <!-- Statistics Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <span class="stat-title">کل قطعات موجود</span>
                            <div class="stat-icon green">
                                <svg viewBox="0 0 24 24">
                                    <path d="M20 6h-2.18c.11-.31.18-.65.18-1a2.996 2.996 0 0 0-5.5-1.65l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1z"/>
                                </svg>
                            </div>
                        </div>
                        <div class="stat-value">۲,۸۴۵</div>
                        <div class="stat-change positive">+۱۵% نسبت به ماه قبل</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <span class="stat-title">سفارشات امروز</span>
                            <div class="stat-icon yellow">
                                <svg viewBox="0 0 24 24">
                                    <path d="M7 18c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12L8.1 13h7.45c.75 0 1.41-.41 1.75-1.03L21.7 4H5.21l-.94-2H1zm16 16c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/>
                                </svg>
                            </div>
                        </div>
                        <div class="stat-value">۱۲۳</div>
                        <div class="stat-change positive">+۸% نسبت به دیروز</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <span class="stat-title">قطعات کم موجود</span>
                            <div class="stat-icon gray">
                                <svg viewBox="0 0 24 24">
                                    <path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>
                                </svg>
                            </div>
                        </div>
                        <div class="stat-value">۴۷</div>
                        <div class="stat-change negative">نیاز به سفارش</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <span class="stat-title">فروش ماهانه</span>
                            <div class="stat-icon green">
                                <svg viewBox="0 0 24 24">
                                    <path d="M3.5 18.49l6-6.01 4 4L22 6.92l-1.41-1.41-7.09 7.97-4-4L2 16.99z"/>
                                </svg>
                            </div>
                        </div>
                        <div class="stat-value">۱,۲۵۰,۰۰۰</div>
                        <div class="stat-change positive">+۲۲% نسبت به ماه قبل</div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="quick-actions">
                    <a href="#" class="action-btn" onclick="showNotification('افزودن قطعه جدید', 'success')">
                        <svg viewBox="0 0 24 24">
                            <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
                        </svg>
                        افزودن قطعه جدید
                    </a>
                    <a href="#" class="action-btn" onclick="showNotification('ثبت سفارش جدید', 'success')">
                        <svg viewBox="0 0 24 24">
                            <path d="M7 18c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12L8.1 13h7.45c.75 0 1.41-.41 1.75-1.03L21.7 4H5.21l-.94-2H1zm16 16c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/>
                        </svg>
                        ثبت سفارش جدید
                    </a>
                    <a href="#" class="action-btn" onclick="showNotification('مدیریت تامین‌کنندگان', 'info')">
                        <svg viewBox="0 0 24 24">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                        مدیریت تامین‌کنندگان
                    </a>
                    <a href="#" class="action-btn" onclick="showNotification('گزارش موجودی', 'info')">
                        <svg viewBox="0 0 24 24">
                            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                        </svg>
                        گزارش موجودی
                    </a>
                </div>
                
                <div class="content-grid">
                    <!-- Inventory Table -->
                    <div class="content-card">
                        <div class="card-header">
                            <h2 class="card-title">
                                <svg viewBox="0 0 24 24">
                                    <path d="M20 6h-2.18c.11-.31.18-.65.18-1a2.996 2.996 0 0 0-5.5-1.65l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1z"/>
                                </svg>
                                موجودی قطعات
                            </h2>
                            <a href="#" class="view-all-btn">
                                مشاهده همه
                                <svg viewBox="0 0 24 24" width="16" height="16">
                                    <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/>
                                </svg>
                            </a>
                        </div>
                        
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>کد قطعه</th>
                                        <th>نام قطعه</th>
                                        <th>خودرو</th>
                                        <th>موجودی</th>
                                        <th>وضعیت</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>BP-001</td>
                                        <td>لنت ترمز جلو</td>
                                        <td>پژو ۲۰۶</td>
                                        <td>۱۲۵</td>
                                        <td><span class="status-badge status-available">موجود</span></td>
                                    </tr>
                                    <tr>
                                        <td>ENG-045</td>
                                        <td>فیلتر روغن</td>
                                        <td>سمند</td>
                                        <td>۸</td>
                                        <td><span class="status-badge status-low">کم موجود</span></td>
                                    </tr>
                                    <tr>
                                        <td>TR-089</td>
                                        <td>تایر ۱۸۵/۶۵</td>
                                        <td>پراید</td>
                                        <td>۰</td>
                                        <td><span class="status-badge status-out">ناموجود</span></td>
                                    </tr>
                                    <tr>
                                        <td>SP-234</td>
                                        <td>شمع موتور</td>
                                        <td>دنا</td>
                                        <td>۶۷</td>
                                        <td><span class="status-badge status-available">موجود</span></td>
                                    </tr>
                                    <tr>
                                        <td>GB-156</td>
                                        <td>روغن گیربکس</td>
                                        <td>تیبا</td>
                                        <td>۱۵</td>
                                        <td><span class="status-badge status-low">کم موجود</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Settings Form -->
                    <div class="content-card">
                        <div class="card-header">
                            <h2 class="card-title">
                                <svg viewBox="0 0 24 24">
                                    <path d="M19.14,12.94c0.04-0.3,0.06-0.61,0.06-0.94c0-0.32-0.02-0.64-0.07-0.94l2.03-1.58c0.18-0.14,0.23-0.41,0.12-0.61 l-1.92-3.32c-0.12-0.22-0.37-0.29-0.59-0.22l-2.39,0.96c-0.5-0.38-1.03-0.7-1.62-0.94L14.4,2.81c-0.04-0.24-0.24-0.41-0.48-0.41 h-3.84c-0.24,0-0.43,0.17-0.47,0.41L9.25,5.35C8.66,5.59,8.12,5.92,7.63,6.29L5.24,5.33c-0.22-0.08-0.47,0-0.59,0.22L2.74,8.87 C2.62,9.08,2.66,9.34,2.86,9.48l2.03,1.58C4.84,11.36,4.8,11.69,4.8,12s0.02,0.64,0.07,0.94l-2.03,1.58 c-0.18,0.14-0.23,0.41-0.12,0.61l1.92,3.32c0.12,0.22,0.37,0.29,0.59,0.22l2.39-0.96c0.5,0.38,1.03,0.7,1.62,0.94l0.36,2.54 c0.05,0.24,0.24,0.41,0.48,0.41h3.84c0.24,0,0.44-0.17,0.47-0.41l0.36-2.54c0.59-0.24,1.13-0.56,1.62-0.94l2.39,0.96 c0.22,0.08,0.47,0,0.59-0.22l1.92-3.32c0.12-0.22,0.07-0.47-0.12-0.61L19.14,12.94z M12,15.6c-1.98,0-3.6-1.62-3.6-3.6 s1.62-3.6,3.6-3.6s3.6,1.62,3.6,3.6S13.98,15.6,12,15.6z"/>
                                </svg>
                                تنظیمات انبار
                            </h2>
                        </div>
                        
                        <form class="settings-form" onsubmit="handleSettingsSubmit(event)">
                            <div class="form-group">
                                <label for="warehouse-name" class="form-label">نام انبار</label>
                                <input type="text" id="warehouse-name" class="form-input" value="انبار مرکزی قطعات">
                            </div>
                            
                            <div class="form-group">
                                <label for="min-stock" class="form-label">حداقل موجودی هشدار</label>
                                <input type="number" id="min-stock" class="form-input" value="10">
                            </div>
                            
                            <div class="form-group">
                                <label for="currency" class="form-label">واحد پول</label>
                                <select id="currency" class="form-select">
                                    <option value="rial">ریال</option>
                                    <option value="toman">تومان</option>
                                    <option value="dollar">دلار</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="auto-order" class="form-label">سفارش خودکار</label>
                                <select id="auto-order" class="form-select">
                                    <option value="enabled">فعال</option>
                                    <option value="disabled">غیرفعال</option>
                                </select>
                            </div>
                            
                            <div class="btn-group">
                                <button type="submit" class="btn btn-primary">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                    </svg>
                                    ذخیره تغییرات
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="resetForm()">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/>
                                    </svg>
                                    بازنشانی
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
<?php include('include/footer_admin.php')?>
<?php include('include/main_admin.php') ;
include('include/db.php');

$user_id = $_GET['id'];

$query_select = "SELECT * FROM user WHERE user_id = '$user_id'";
$result_select = mysqli_query($conn,$query_select);
$row = mysqli_fetch_array($result_select);

?>

<!-- Mobile Sidebar Overlay -->
<div class="sidebar-overlay" onclick="closeMobileMenu()"></div>
<div class="dashboard-container">
    <!-- Sidebar -->
    <?php include('include/header_admin.php')?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navigation -->
        <header class="top-nav">
            <div style="display: flex; align-items: center;">
                <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                    <svg viewBox="0 0 24 24">
                        <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                    </svg>
                </button>
                <h1 class="page-title">مدیریت کامنت ها</h1>
            </div>
            <div class="top-nav-actions">
                <div class="search-box">
                    <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                    <svg class="search-icon" viewBox="0 0 24 24">
                        <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                    </svg>
                </div>
                <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                    <svg class="notification-icon" viewBox="0 0 24 24">
                        <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                    </svg>
                    <div class="notification-badge">۵</div>
                </button>
            </div>
        </header>

        <!-- Dashboard Content -->
        <main class="p-6 space-y-6">

            <!-- اطلاعات کاربر -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <div class="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                    <!-- آواتار -->
                    <div class="w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-lg">
                        ع م
                    </div>

                    <!-- اطلاعات کاربر -->
                    <div class="w-full text-center sm:text-right">
                        
                        <p class="text-2xl font-bold text-gray-800 mb-6">اطلاعات کاربر همراه با کامنت</p>
                        <h2 class="text-xl font-bold text-green-700 mb-5"><?php echo htmlspecialchars($row['fullName'])?></h2>
                        <div class="space-y-3 text-sm">
                            <p class="text-gray-600 flex items-center justify-center sm:justify-start gap-2">
                                <svg class="w-5 h-5 text-gray-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                </svg>
                                <span>نام کاربری: <span class="font-medium"><?php echo htmlspecialchars($row['username'])?></span></span>
                            </p>
                            <p class="text-gray-600 flex items-center justify-center sm:justify-start gap-2">
                                <svg class="w-5 h-5 text-gray-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                </svg>
                                <span>ایمیل: <span class="font-medium"><?php echo htmlspecialchars($row['email'])?></span></span>
                            </p>
                            <p class="text-gray-600 flex items-center justify-center sm:justify-start gap-2">
                                <svg class="w-5 h-5 text-gray-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                                </svg>
                                <span>تلفن: <span class="font-medium"><?php echo htmlspecialchars($row['phone'])?></span></span>
                            </p>
                            <p class="text-gray-600 flex items-center justify-center sm:justify-start gap-2">
                                <svg class="w-5 h-5 text-gray-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span>تاریخ ثبت‌نام: <span class="font-medium"><?php echo htmlspecialchars($row['created_at'])?></span></span>
                            </p>
                        </div>

                    </div>
                </div>
            </div>

            <!-- کامنت‌ها به صورت کارت -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <div class="space-y-6">

                    <!-- کارت کامنت ۱ -->
                    <div class="border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300">
                        <!-- هدر: محصول + وضعیت -->
                        <div class="bg-gradient-to-l from-purple-50 to-pink-50 p-4 border-b border-gray-200">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-12 h-12 bg-gray-200 border-2 border-dashed rounded-lg flex items-center justify-center">
                                        <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                        </svg>
                                    </div>
                                    <div>
                                        <h3 class="font-bold text-purple-800">لنت ترمز جلو پراید</h3>
                                        <p class="text-xs text-gray-500">کد محصول: #PRD-12345</p>
                                    </div>
                                </div>

                                <!-- وضعیت + دکمه تغییر -->
                                <div class="flex items-center gap-2">
                                    <span class="px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 bg-green-100 text-green-800">
                                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                                        </svg>
                                        فعال
                                    </span>
                                    <button class="p-2 rounded-lg bg-red-100 hover:bg-red-200 text-red-600 transition-all">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- بدنه کامنت -->
                        <div class="p-5">
                            <div class="flex items-start gap-3">
                                <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-700 font-bold text-sm">
                                    ع م
                                </div>
                                <div class="flex-1">
                                    <p class="text-gray-800 leading-relaxed">سلام، من راضی ام. کیفیت عالی بود و به موقع رسید.</p>
                                    <p class="text-xs text-gray-500 mt-2">ارسال شده در: ۱۴:۳۰ - ۱۴۰۳/۰۷/۱۵</p>
                                </div>
                            </div>
                        </div>

                        <!-- فرم پاسخ -->
                        <div class="p-4 bg-gray-50 border-t border-gray-200">
                            <form class="flex gap-2">
                                <textarea rows="2" class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1F7D3B] focus:border-transparent resize-none text-sm" placeholder="پاسخ خود را بنویسید..."></textarea>
                                <button type="submit" class="px-5 py-2 bg-[#1F7D3B] text-white rounded-lg hover:bg-[#1a6a32] transition-all font-medium text-sm flex items-center gap-1">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                                    </svg>
                                    ارسال
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- کارت کامنت ۲ (غیرفعال) -->
                    <div class="border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300">
                        <div class="bg-gradient-to-l from-purple-50 to-pink-50 p-4 border-b border-gray-200">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-12 h-12 bg-gray-200 border-2 border-dashed rounded-lg flex items-center justify-center">
                                        <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                        </svg>
                                    </div>
                                    <div>
                                        <h3 class="font-bold text-purple-800">فیلتر روغن پژو 405</h3>
                                        <p class="text-xs text-gray-500">کد محصول: #PRD-67890</p>
                                    </div>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 bg-red-100 text-red-800">
                                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                                        </svg>
                                        غیرفعال
                                    </span>
                                    <button class="p-2 rounded-lg bg-green-100 hover:bg-green-200 text-green-600 transition-all">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="p-5">
                            <div class="flex items-start gap-3">
                                <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-700 font-bold text-sm">
                                    ع م
                                </div>
                                <div class="flex-1">
                                    <p class="text-gray-800 leading-relaxed">محصول دیر رسید و بسته‌بندی آسیب دیده بود.</p>
                                    <p class="text-xs text-gray-500 mt-2">ارسال شده در: ۱۰:۴۵ - ۱۴۰۳/۰۷/۱۲</p>
                                </div>
                            </div>

                            <!-- پاسخ ادمین -->
                            <div class="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                                <div class="flex items-start gap-2">
                                    <svg class="w-5 h-5 text-blue-600 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m7.414-9.828V6a3 3 0 00-3-3H7a3 3 0 00-3 3v7a3 3 0 003 3h2v4l4-4h3a3 3 0 003-3V8z"></path>
                                    </svg>
                                    <div>
                                        <p class="text-sm font-medium text-blue-800">پاسخ ادمین:</p>
                                        <p class="text-sm text-blue-700 mt-1">با عرض پوزش، مشکل بسته‌بندی بررسی شد. ارسال مجدد رایگان انجام شد.</p>
                                        <p class="text-xs text-blue-500 mt-1">۱۴:۲۰ - ۱۴۰۳/۰۷/۱۲</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- پیام عدم وجود کامنت -->
                    <!-- <p class="text-gray-500 text-center py-8">هیچ کامنتی برای این کاربر ثبت نشده است.</p> -->

                </div>
            </div>

        </main>
    </div>
</div>

<?php include('include/footer_admin.php') ?>
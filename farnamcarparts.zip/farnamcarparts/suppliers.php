<?php include('include/main_admin.php')?>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

<style>
  .accent-bg { 
    background: linear-gradient(135deg, rgba(242, 194, 42, 0.06) 0%, rgba(31, 125, 59, 0.02) 100%);
  }
  .table-shadow { 
    box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1), 
                0 10px 10px -5px rgba(0,0,0,0.04);
  }
  .sidebar-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.5);
    z-index: 40;
    display: none;
  }
</style>

<div class="sidebar-overlay"></div>

<div class="dashboard-container" dir="rtl">
<?php include('include/header_admin.php')?>    

<div class="main-content">

    <!-- Page Title -->
   <header class="top-nav">
                <div style="display: flex; align-items: center;">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                        </svg>
                    </button>
                    <h1 class="page-title">مدیریت تأمین‌کنندگان</h1>
                </div>
                <div class="top-nav-actions">
                    <div class="search-box">
                        <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                        <svg class="search-icon" viewBox="0 0 24 24">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                        </svg>
                    </div>
                    <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                        <svg class="notification-icon" viewBox="0 0 24 24">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                        <div class="notification-badge">۵</div>
                    </button>
                </div>
            </header>

    <!-- Add Supplier Button -->
    <div class="p-4">
        <a href="add_supplier.php"
           class="inline-flex items-center justify-center px-6 py-3 bg-green-700 hover:bg-green-800 text-white font-medium rounded-xl shadow-md transition">
            <svg class="w-5 h-5 ml-2 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                 d="M12 4v16m8-8H4"/>
            </path>
            </svg>
            افزودن تأمین‌کننده
        </a>
    </div>

    <!-- Table -->
    <main class="dashboard-content p-4 accent-bg min-h-screen">
        <div class="overflow-x-auto bg-white rounded-2xl table-shadow">
            <table class="w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-gray-700">شناسه</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-gray-700">نام تأمین‌کننده</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-gray-700">شماره تماس</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-gray-700">نام شرکت</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-gray-700">ایمیل</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-gray-700">آدرس</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold text-gray-700">عملیات</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">

                    <!-- Sample row -->
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-4 py-3 text-sm">#S001</td>
                        <td class="px-4 py-3 text-sm">علی جمشیدی</td>
                        <td class="px-4 py-3 text-sm">09121234567</td>
                        <td class="px-4 py-3 text-sm">قطعه سازان شرق</td>
                        <td class="px-4 py-3 text-sm">info@example.com</td>
                        <td class="px-4 py-3 text-sm">تهران، خیابان آزادی</td>
                        <td class="px-4 py-3 flex space-x-2 rtl:space-x-reverse">
                            <a href="edit_supplier.php" class="text-blue-600 hover:text-blue-800">
                                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                     d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                </svg>
                            </a>
                            <a href="#" class="text-red-600 hover:text-red-800">
                                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                     d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                </svg>
                            </a>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    </main>
</div>

</div>

<?php include('include/footer_admin.php')?>

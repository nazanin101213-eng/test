<?php include('include/main_admin.php')?>

<style>
  .accent-bg { 
    background: linear-gradient(135deg, rgba(242, 194, 42, 0.06) 0%, rgba(31, 125, 59, 0.02) 100%);
  }
  .sidebar-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background-color: rgba(0,0,0,0.5);
    z-index: 40;
    display: none;
  }
  .sidebar-overlay.active { display: block; }

  .status-card {
    min-width: 150px;
    padding: 1rem;
    border-radius: 1rem;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
  }
  .status-all { background-color: #1F7D3B; }
  .status-pending { background-color: #F2C22A; color: #000; }
  .status-shipped { background-color: #38BDF8; }
  .status-delivered { background-color: #10B981; }
  .status-returned { background-color: #F97316; }
  .status-canceled { background-color: #EF4444; }
</style>

<div class="sidebar-overlay"></div>

<div class="dashboard-container" dir="rtl">
    <?php include('include/header_admin.php')?>

    <div class="main-content">
        <!-- Page Header -->
        <header class="top-nav">
                <div style="display: flex; align-items: center;">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                        </svg>
                    </button>
                    <h1 class="page-title">مدیریت سفارشات</h1>
                </div>
                <div class="top-nav-actions">
                    <div class="search-box">
                        <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                        <svg class="search-icon" viewBox="0 0 24 24">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                        </svg>
                    </div>
                    <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                        <svg class="notification-icon" viewBox="0 0 24 24">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                        <div class="notification-badge">۵</div>
                    </button>
                </div>
            </header>

        <div class="px-6 md:px-12">
            <!-- Status Cards -->
            <div class="mt-4 flex flex-wrap gap-4">
                <div class="status-card status-all">
                    <span>همه سفارشات</span>
                    <span>13</span>
                </div>
                <div class="status-card status-pending">
                    <span>در انتظار</span>
                    <span>4</span>
                </div>
                <div class="status-card status-shipped">
                    <span>ارسال شده</span>
                    <span>2</span>
                </div>
                <div class="status-card status-delivered">
                    <span>تحویل داده شده</span>
                    <span>1</span>
                </div>
                <div class="status-card status-returned">
                    <span>بازگشت محصول</span>
                    <span>2</span>
                </div>
                <div class="status-card status-canceled">
                    <span>لغو شده</span>
                    <span>0</span>
                </div>
            </div>

            <!-- Filters -->
            <div class="mt-4 p-4 bg-white shadow rounded-xl flex flex-wrap gap-4 rtl">
                <select class="border px-3 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600">
                    <option value="">انتخاب وضعیت</option>
                    <option value="pending">در انتظار</option>
                    <option value="processing">در حال پردازش</option>
                    <option value="completed">تکمیل شده</option>
                    <option value="canceled">لغو شده</option>
                </select>
                <input type="text" placeholder="نام مشتری" class="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-600">
                <input type="text" placeholder="نام محصول" class="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-600">
                <input type="date" class="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-600">
                <input type="date" class="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-600">
                <button class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 shadow-md">اعمال فیلتر</button>
            </div>

            <!-- Orders Table -->
            <main class="dashboard-content mt-4 p-4 accent-bg min-h-screen">
                <div class="overflow-x-auto bg-white rounded-lg shadow-md">
                    <table class="w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">شناسه سفارش</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">نام مشتری</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">شماره تماس</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">ایمیل</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">آدرس</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">محصولات سفارش داده شده</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">تعداد</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">قیمت کل</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">وضعیت</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">تاریخ سفارش</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">تاریخ تحویل</th>
                                <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">عملیات</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-4 py-3 text-sm">ORD-001</td>
                                <td class="px-4 py-3 text-sm">محمد رضایی</td>
                                <td class="px-4 py-3 text-sm">09123456789</td>
                                <td class="px-4 py-3 text-sm">m.rezaei@example.com</td>
                                <td class="px-4 py-3 text-sm">m.rezaei@example.com</td>
                                <td class="px-4 py-3 text-sm">لنت ترمز، فیلتر روغن</td>
                                <td class="px-4 py-3 text-sm">3</td>
                                <td class="px-4 py-3 text-sm">1,250,000 ریال</td>
                                <td class="px-4 py-3">
                                    <span class="px-2 py-1 rounded-full text-white bg-green-600 text-xs">تکمیل شده</span>
                                </td>
                                <td class="px-4 py-3 text-sm">1402/07/01</td>
                                <td class="px-4 py-3 text-sm">1402/07/05</td>
                                <td class="px-4 py-3 flex space-x-2 rtl:space-x-reverse">
                                    <a href="#" class="text-blue-600 hover:text-blue-800">
                                        ویرایش
                                    </a>
                                    <a href="#" class="text-red-600 hover:text-red-800">
                                        حذف
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
</div>

<?php include('include/footer_admin.php')?>

<?php
include('include/db.php');


if(isset($_POST['full_name']) && !empty($_POST['full_name']) &&
   isset($_POST['user_name']) && !empty($_POST['user_name']) &&
   isset($_POST['phone']) && !empty($_POST['phone']) &&
   isset($_POST['email']) && !empty($_POST['email']) &&
   isset($_POST['password']) && !empty($_POST['password']) &&
   isset($_POST['confirm_password']) && !empty($_POST['confirm_password']) &&
   isset($_POST['admin_type']) && !empty($_POST['admin_type'])){

    $full_name = $_POST['full_name'];
    $user_name = $_POST['user_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $admin_type = $_POST['admin_type'];
   }
   else{
    echo"<script>alert('لطفا تمام فیلد هارا پر کنید'); window.location.href='add_admin.php';</script>";
    exit();
   }
   if(!filter_var($email,FILTER_VALIDATE_EMAIL))
   {
    echo "<script>alert('فرمت ایمیل درست نمی باشد');window.location.href='add_admin.php';</script>";
    exit();
   }
   if($password != $confirm_password){
    echo "<script>alert('رمز عبور با تکرار آن یکی نمی باشد. لطفا دوباره امتحان کنید');window.location.href='add_admin.php';</script>";
    exit();
   }


   $stmt = $conn->prepare("SELECT * FROM user WHERE username = ?");
   $stmt ->bind_param('s',$user_name);
   $stmt->execute();
   $stmt->store_result();

   if($stmt->num_rows>0)
   {
    echo "<script>alert('این نام کاربری وجود دارد'); window.location.href='add_admin.php';</script>";
    exit();
   }

   $passwordHash = password_hash($password,PASSWORD_DEFAULT);
   $stmt = $conn->prepare("INSERT INTO user (username, fullName, email, phone, type, active, pass) VALUES (?, ?, ?, ?, ?, 1, ?)");
   $stmt->bind_param('ssssss',$user_name,$full_name,$email,$phone,$admin_type,$passwordHash);
   $stmt->execute();
   echo "<script>alert('با موفقیت ثبت شد'); window.location.href='manage_user.php';</script>";


   
   $conn -> close();
?>
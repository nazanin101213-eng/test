<?php include('include/main_admin.php');
include('include/db.php');

$user_id = $_GET['id'];
$query_select = "SELECT * FROM user WHERE user_id = '$user_id'";
$result_select = mysqli_query($conn,$query_select);
$row_user = mysqli_fetch_array($result_select);
?>

<!-- Mobile Sidebar Overlay -->
<div class="sidebar-overlay" onclick="closeMobileMenu()"></div>
<div class="dashboard-container">
    <!-- Sidebar -->
    <?php include('include/header_admin.php')?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navigation -->
        <header class="top-nav">
            <div style="display: flex; align-items: center;">
                <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                    <svg viewBox="0 0 24 24">
                        <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                    </svg>
                </button>
                <h1 class="page-title">مدیریت تیکت پشتیبانی</h1>
            </div>
            <div class="top-nav-actions">
                <div class="search-box">
                    <input type="text" class="search-input" placeholder="جستجوی تیکت، کاربر، کد...">
                    <svg class="search-icon" viewBox="0 0 24 24">
                        <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                    </svg>
                </div>
                <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                    <svg class="notification-icon" viewBox="0 0 24 24">
                        <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                    </svg>
                    <div class="notification-badge">۵</div>
                </button>
            </div>
        </header>

        <!-- Dashboard Content -->
        <main class="p-6 space-y-6">

            <!-- اطلاعات کاربر -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <div class="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                    <!-- عکس پروفایل -->
                    <img src="https://via.placeholder.com/96" 
                         alt="عکس پروفایل" 
                         class="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg">

                    <!-- اطلاعات کاربر -->
                    <div class="w-full text-center sm:text-right">
                        <p class="text-2xl font-bold text-gray-800 mb-6">اطلاعات کاربر همراه با سوابق تیکت‌ها</p>
                        <h2 class="text-xl font-bold text-green-700 mb-5"><?php echo htmlspecialchars($row_user['fullName'])?></h2>
                        <div class="space-y-3 text-sm">
                            <p class="text-gray-600 flex items-center justify-center sm:justify-start gap-2">
                                <svg class="w-5 h-5 text-gray-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                </svg>
                                <span>نام کاربری: <span class="font-medium"><?php echo htmlspecialchars($row_user['username'])?></span></span>
                            </p>
                            <p class="text-gray-600 flex items-center justify-center sm:justify-start gap-2">
                                <svg class="w-5 h-5 text-gray-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                </svg>
                                <span>ایمیل: <span class="font-medium"><?php echo htmlspecialchars($row_user['email'])?></span></span>
                            </p>
                            <p class="text-gray-600 flex items-center justify-center sm:justify-start gap-2">
                                <svg class="w-5 h-5 text-gray-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                                </svg>
                                <span>تلفن: <span class="font-medium"><?php echo htmlspecialchars($row_user['phone'])?></span></span>
                            </p>
                            <p class="text-gray-600 flex items-center justify-center sm:justify-start gap-2">
                                <svg class="w-5 h-5 text-gray-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                </svg>
                                <span>تاریخ ثبت‌نام: <span class="font-medium"><?php echo htmlspecialchars($row_user['created_at'])?></span></span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- تیکت‌ها به صورت کارت -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <h2 class="text-lg font-bold mb-5 flex items-center gap-2">
                    <svg class="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
                    </svg>
                    تیکت‌های کاربر
                </h2>

                <div class="space-y-6">

                    <!-- کارت تیکت ۱ -->
                    <div class="border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300">
                        <!-- هدر تیکت -->
                        <div class="bg-gradient-to-r from-indigo-50 to-purple-50 p-4 border-b border-gray-200">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-16 h-16 bg-gray-200 border-2 border-dashed rounded-lg flex items-center justify-center">
                                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                        </svg>
                                    </div>
                                    <div>
                                        <h3 class="font-bold text-indigo-800">مشکل در ارسال سفارش #12345</h3>
                                        <p class="text-xs text-gray-600">کد تیکت: #TKT-78901</p>
                                    </div>
                                </div>

                                <!-- وضعیت تیکت -->
                                <div class="flex items-center gap-2">
                                    <span class="px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 bg-yellow-100 text-yellow-800">
                                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"></path>
                                        </svg>
                                        در انتظار پاسخ
                                    </span>
                                </div>
                            </div>
                        </div>

                        <!-- بدنه تیکت -->
                        <div class="p-5">
                            <div class="flex items-start gap-3">
                                <div class="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-700 font-bold text-sm">
                                    ع م
                                </div>
                                <div class="flex-1">
                                    <p class="text-gray-800 leading-relaxed">سلام، سفارشم ۳ روزه ارسال نشده. پیگیری کنید لطفاً.</p>
                                    <p class="text-xs text-gray-500 mt-2">ارسال شده در: ۱۰:۴۵ - ۱۴۰۳/۰۷/۱۲</p>
                                </div>
                            </div>
                        </div>

                        <!-- فرم پاسخ -->
                        <div class="p-4 bg-gray-50 border-t border-gray-200">
                            <form class="flex gap-2">
                                <textarea rows="2" class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none text-sm" placeholder="پاسخ خود را بنویسید..."></textarea>
                                <button type="submit" class="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all font-medium text-sm flex items-center gap-1">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                                    </svg>
                                    ارسال
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- کارت تیکت ۲ (پاسخ داده شده) -->
                    <div class="border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300">
                        <div class="bg-gradient-to-r from-indigo-50 to-purple-50 p-4 border-b border-gray-200">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-16 h-16 bg-gray-200 border-2 border-dashed rounded-lg flex items-center justify-center">
                                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                        </svg>
                                    </div>
                                    <div>
                                        <h3 class="font-bold text-indigo-800">سوال در مورد گارانتی</h3>
                                        <p class="text-xs text-gray-600">کد تیکت: #TKT-12345</p>
                                    </div>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 bg-green-100 text-green-800">
                                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                                        </svg>
                                        پاسخ داده شده
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="p-5">
                            <div class="flex items-start gap-3">
                                <div class="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-700 font-bold text-sm">
                                    ع م
                                </div>
                                <div class="flex-1">
                                    <p class="text-gray-800 leading-relaxed">سلام، گارانتی این قطعه چند ماهه؟</p>
                                    <p class="text-xs text-gray-500 mt-2">ارسال شده در: ۱۴:۳۰ - ۱۴۰۳/۰۷/۱۰</p>
                                </div>
                            </div>

                            <!-- پاسخ ادمین -->
                            <div class="mt-4 p-4 bg-indigo-50 rounded-lg border border-indigo-200">
                                <div class="flex items-start gap-2">
                                    <svg class="w-5 h-5 text-indigo-600 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m7.414-9.828V6a3 3 0 00-3-3H7a3 3 0 00-3 3v7a3 3 0 003 3h2v4l4-4h3a3 3 0 003-3V8z"></path>
                                    </svg>
                                    <div>
                                        <p class="text-sm font-medium text-indigo-800">پاسخ پشتیبانی:</p>
                                        <p class="text-sm text-indigo-700 mt-1">گارانتی ۱۲ ماهه از تاریخ خرید است. فاکتور را نگه دارید.</p>
                                        <p class="text-xs text-indigo-500 mt-1">۱۵:۱۰ - ۱۴۰۳/۰۷/۱۰</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- پیام عدم وجود تیکت -->
                <!-- <p class="text-center text-gray-500 py-8">هیچ تیکتی برای این کاربر ثبت نشده است.</p> -->
            </div>

        </main>
    </div>
</div>

<?php include('include/footer_admin.php') ?>
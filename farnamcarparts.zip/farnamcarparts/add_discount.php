<?php include('include/main_admin.php')?>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<style>
  .accent-bg { 
    background: 
      linear-gradient(135deg, rgba(242, 194, 42, 0.06) 0%, rgba(31, 125, 59, 0.02) 100%),
      url("data:image/svg+xml,%3Csvg width='120' height='120' viewBox='0 0 120 120' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' stroke='%23F2C22A' stroke-width='1.5' stroke-opacity='0.04'%3E%3Cpath d='M60 15a45 45 0 0 1 0 90 45 45 0 0 1 0-90zm0 75a30 30 0 0 0 0-60 30 30 0 0 0 0 60z'/%3E%3Ccircle cx='60' cy='60' r='15'/%3E%3C/g%3E%3C/svg%3E") repeat;
  }
  .sidebar-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 40;
    display: none;
  }
  .sidebar-overlay.active {
    display: block;
  }
</style>

<!-- Mobile Sidebar Overlay (above dashboard) -->
<div class="sidebar-overlay" onclick="closeMobileMenu()"></div>

<div class="dashboard-container" dir="rtl">
    <?php include('include/header_admin.php')?>
    <div class="main-content">
       <header class="top-nav">
                <div style="display: flex; align-items: center;">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                        </svg>
                    </button>
                    <h1 class="page-title">افزودن تخفیف جدید</h1>
                </div>
                <div class="top-nav-actions">
                    <div class="search-box">
                        <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                        <svg class="search-icon" viewBox="0 0 24 24">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                        </svg>
                    </div>
                    <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                        <svg class="notification-icon" viewBox="0 0 24 24">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                        <div class="notification-badge">۵</div>
                    </button>
                </div>
            </header>

        <main class="dashboard-content p-4 md:p-6 lg:p-8 accent-bg min-h-screen">
            <div class="max-w-3xl mx-auto">
                <!-- Central Form Card -->
                <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
                    <div class="p-6 md:p-8 lg:p-10">
                        <h2 class="text-xl md:text-2xl font-bold text-gray-900 mb-8 text-center">افزودن تخفیف جدید</h2>

                        <!-- Simulate Selected Product Data (Replace with real PHP fetch) -->
                        <?php
                        $product = [
                            'id' => 123,
                            'code' => 'OIL-FT-882',
                            'name' => 'فیلتر روغن موتور',
                            'type' => 'موتور',
                            'price' => 285000
                        ];
                        ?>

                        <form id="addDiscountForm" class="space-y-6" action="process_add_discount.php" method="POST" novalidate>
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">

                            <!-- Product Info - Disabled -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-gray-50 rounded-xl">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">شناسه</label>
                                    <input type="text" value="#<?php echo str_pad($product['id'], 4, '0', STR_PAD_LEFT); ?>" disabled class="block w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-sm text-gray-600 cursor-not-allowed">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">کد محصول</label>
                                    <input type="text" value="<?php echo $product['code']; ?>" disabled class="block w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-sm text-gray-600 font-mono cursor-not-allowed">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">نام محصول</label>
                                    <input type="text" value="<?php echo $product['name']; ?>" disabled class="block w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-sm text-gray-600 cursor-not-allowed">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">نوع محصول</label>
                                    <div class="flex items-center">
                                        <span class="px-3 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800"><?php echo $product['type']; ?></span>
                                    </div>
                                </div>
                                <div class="md:col-span-2">
                                    <label class="block text-sm font-medium text-gray-700 mb-1">قیمت</label>
                                    <input type="text" value="<?php echo number_format($product['price']); ?> تومان" disabled class="block w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-sm text-gray-600 cursor-not-allowed">
                                </div>
                            </div>

                            <!-- Discount Type -->
                            <div>
                                <label for="discount_type" class="block text-sm font-medium text-gray-700 mb-2">نوع تخفیف</label>
                                <div class="relative">
                                    <select id="discount_type" name="discount_type" required
                                            class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition text-base">
                                        <option value="" disabled selected>انتخاب کنید</option>
                                        <option value="percent">درصدی (%)</option>
                                        <option value="fixed">مبلغ ثابت (تومان)</option>
                                    </select>
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                        <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/>
                                        </svg>
                                    </div>
                                </div>
                            </div>

                            <!-- Discount Value -->
                            <div>
                                <label for="discount_value" class="block text-sm font-medium text-gray-700 mb-2">مقدار تخفیف</label>
                                <div class="relative">
                                    <input type="number" id="discount_value" name="discount_value" min="0" step="1" required
                                           class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition text-base"
                                           placeholder="مثلاً 15 یا 50000">
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                        <span id="discount-unit" class="text-gray-400 text-sm">—</span>
                                    </div>
                                </div>
                                <p class="mt-1 text-xs text-gray-500">برای درصد: 1–100 | برای مبلغ: حداکثر قیمت محصول</p>
                            </div>

                            <!-- Status Toggle -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">وضعیت</label>
                                <div class="flex items-center">
                                    <button type="button" id="status-toggle" class="relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500" role="switch" aria-checked="true">
                                        <span class="translate-x-5 pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200"></span>
                                    </button>
                                    <span id="status-label" class="mr-3 text-sm font-medium text-green-700">فعال</span>
                                    <input type="hidden" name="status" value="1">
                                </div>
                            </div>

                            <!-- Date Range -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="start_date" class="block text-sm font-medium text-gray-700 mb-2">تاریخ شروع</label>
                                    <div class="relative">
                                        <input type="date" id="start_date" name="start_date" required
                                               class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition text-base">
                                        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                            <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <label for="end_date" class="block text-sm font-medium text-gray-700 mb-2">تاریخ پایان</label>
                                    <div class="relative">
                                        <input type="date" id="end_date" name="end_date" required
                                               class="block w-full pr-10 pl-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition text-base">
                                        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                            <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Action Buttons -->
                            <div class="flex flex-col sm:flex-row gap-3 pt-6">
                                <!-- Save Discount - Green -->
                                <button type="submit"
                                        class="flex-1 flex justify-center items-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-base font-medium text-white bg-green-700 hover:bg-green-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-200">
                                    <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                    </svg>
                                    ذخیره تخفیف
                                </button>

                                <!-- Reset - Gray -->
                                <button type="reset"
                                        class="flex-1 flex justify-center items-center py-3 px-4 border border-gray-300 rounded-xl shadow-sm text-base font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-200">
                                    <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                                    </svg>
                                    بازنشانی
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php include('include/footer_admin.php')?>

<!-- Client-side Logic -->
<script>
    // Update discount unit
    document.getElementById('discount_type').addEventListener('change', function() {
        const unit = this.value === 'percent' ? '%' : 'تومان';
        document.getElementById('discount-unit').textContent = unit;
        document.getElementById('discount_value').placeholder = this.value === 'percent' ? 'مثلاً 15' : 'مثلاً 50000';
    });

    // Status Toggle
    const toggle = document.getElementById('status-toggle');
    const label = document.getElementById('status-label');
    const hiddenInput = document.querySelector('input[name="status"]');

    toggle.addEventListener('click', function() {
        const isActive = toggle.getAttribute('aria-checked') === 'true';
        toggle.setAttribute('aria-checked', !isActive);
        toggle.classList.toggle('bg-green-600', !isActive);
        toggle.classList.toggle('bg-gray-300', isActive);
        const span = toggle.querySelector('span');
        span.classList.toggle('translate-x-0', isActive);
        span.classList.toggle('translate-x-5', !isActive);
        label.textContent = !isActive ? 'فعال' : 'غیرفعال';
        label.classList.toggle('text-green-700', !isActive);
        label.classList.toggle('text-gray-600', isActive);
        hiddenInput.value = !isActive ? '1' : '0';
    });

    // Form Validation
    document.getElementById('addDiscountForm').addEventListener('submit', function(e) {
        const type = document.getElementById('discount_type').value;
        const value = parseFloat(document.getElementById('discount_value').value);
        const start = document.getElementById('start_date').value;
        const end = document.getElementById('end_date').value;
        const price = <?php echo $product['price']; ?>;

        // Required fields
        if (!type || !value || !start || !end) {
            e.preventDefault();
            alert('لطفاً تمام فیلدهای الزامی را پر کنید.');
            return;
        }

        // Discount value validation
        if (type === 'percent' && (value < 1 || value > 100)) {
            e.preventDefault();
            alert('مقدار درصد باید بین 1 تا 100 باشد.');
            return;
        }
        if (type === 'fixed' && value > price) {
            e.preventDefault();
            alert('مقدار تخفیف ثابت نمی‌تواند بیشتر از قیمت محصول باشد.');
            return;
        }

        // Date range
        if (new Date(start) > new Date(end)) {
            e.preventDefault();
            alert('تاریخ شروع نمی‌تواند بعد از تاریخ پایان باشد.');
            return;
        }
    });
</script>
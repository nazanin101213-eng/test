<?php include('include/main_admin.php')?>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

<style>
        .card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .chart-container {
            position: relative;
            height: 250px;
        }
        .filter-btn.active {
            background-color: #15803d !important;
            color: white !important;
            border-color: #15803d !important;
        }
        .positive-change {
            color: #10b981;
        }
        .negative-change {
            color: #ef4444;
        }
</style>

<div class="sidebar-overlay"></div>

<div class="dashboard-container" dir="rtl">
<?php include('include/header_admin.php')?>    

<div class="main-content">

    <!-- Page Title -->
    <header class="top-nav">
                <div style="display: flex; align-items: center;">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                        </svg>
                    </button>
                    <h1 class="page-title"> داشبورد گزارش‌گیری مالی و فروش</h1>
                </div>
                <div class="top-nav-actions">
                    <div class="search-box">
                        <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                        <svg class="search-icon" viewBox="0 0 24 24">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                        </svg>
                    </div>
                    <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                        <svg class="notification-icon" viewBox="0 0 24 24">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                        <div class="notification-badge">۵</div>
                    </button>
                </div>
            </header>

    <!-- Add Supplier Button -->
    <!-- <div class="p-4">
        <a href="add_supplier.php"
           class="inline-flex items-center justify-center px-6 py-3 bg-green-700 hover:bg-green-800 text-white font-medium rounded-xl shadow-md transition">
            <svg class="w-5 h-5 ml-2 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                 d="M12 4v16m8-8H4"/>
            </path>
            </svg>
            افزودن تأمین‌کننده
        </a>
    </div> -->
    <header class="mb-8">
                        <div class="mt-4 flex flex-wrap gap-2">
                            <div class="flex flex-wrap gap-2">
                                <button id="filter-day" class="filter-btn bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm hover:bg-gray-50">
                                    امروز
                                </button>
                                <button id="filter-week" class="filter-btn bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm hover:bg-gray-50 active">
                                    این هفته
                                </button>
                                <button id="filter-month" class="filter-btn bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm hover:bg-gray-50">
                                    این ماه
                                </button>
                                <button id="filter-year" class="filter-btn bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm hover:bg-gray-50">
                                    امسال
                                </button>
                            </div>
                        </div>

                        <div class="mt-4 text-sm text-green-600 bg-green-50 p-3 rounded-lg">
                            <i class="fas fa-info-circle ml-2"></i>
                            فیلترهای زمانی، داده‌های روزانه را بر اساس بازه انتخابی شما جمع‌بندی و نمایش می‌دهند.
                        </div>
                    </header>

    <!-- Table -->
    <main class="dashboard-content p-4 accent-bg min-h-screen">
        <!-- <div class="overflow-x-auto bg-white rounded-2xl table-shadow"> -->
           <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

                    <div class="card bg-white rounded-xl shadow-md p-6 border-l-4 border-green-600">
                            <div class="flex items-center mb-4">
                                <div class="bg-green-200 p-3 rounded-full">
                                    <i class="fas fa-shopping-cart text-green-700 text-xl"></i>
                                </div>
                                <h2 class="text-lg font-semibold mr-3">فروش و سفارش‌ها</h2>
                            </div>
                            <div class="mt-4">
                                <div class="flex justify-between items-center mb-2">
                                    <span class="text-gray-600">مجموع فروش:</span>
                                    <span class="text-xl font-bold text-gray-800" id="total-sales"></span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-gray-600">تعداد سفارش‌ها:</span>
                                    <span class="text-xl font-bold text-gray-800" id="total-orders"></span>
                                </div>
                            </div>
                            <div class="mt-4 pt-4 border-t border-gray-100 flex items-center text-sm" id="sales-change">
                                <i class="fas fa-arrow-up ml-1"></i>
                                <span> افزایش نسبت به ماه گذشته</span>
                            </div>
                        </div>


                        <div class="card bg-white rounded-xl shadow-md p-6 border-l-4 border-green-400">
                            <div class="flex items-center mb-4">
                                <div class="bg-green-50 p-3 rounded-full">
                                    <i class="fas fa-chart-line text-green-500 text-xl"></i>
                                </div>
                                <h2 class="text-lg font-semibold mr-3">میانگین ارزش سفارش</h2>
                            </div>
                            <div class="mt-4 text-center">
                                <div class="text-3xl font-bold text-gray-800 mb-2" id="avg-order"></div>
                                <p class="text-gray-600 text-sm">میانگین مبلغ هر سفارش</p>
                            </div>
                            <div class="mt-4 pt-4 border-t border-gray-100 flex items-center text-sm" id="avg-order-change">
                                <i class="fas fa-arrow-up ml-1"></i>
                                <span>افزایش نسبت به ماه گذشته</span>
                            </div>
                        </div>


                        <div class="card bg-white rounded-xl shadow-md p-6 border-l-4 border-green-500">
                            <div class="flex items-center mb-4">
                                <div class="bg-green-100 p-3 rounded-full">
                                    <i class="fas fa-users text-green-600 text-xl"></i>
                                </div>
                                <h2 class="text-lg font-semibold mr-3">مشتریان جدید</h2>
                            </div>
                            <div class="mt-4 text-center">
                                <div class="text-3xl font-bold text-gray-800 mb-2" id="new-customers"></div>
                                <p class="text-gray-600 text-sm">مشتریان جدید در بازه انتخاب شده</p>
                            </div>
                            <div class="mt-4 pt-4 border-t border-gray-100 flex items-center text-sm" id="customers-change">
                                <i class="fas fa-arrow-up ml-1"></i>
                                <span>افزایش نسبت به ماه گذشته</span>
                            </div>
                        </div>
                    </div>
        <!-- </div> -->
          <div class="mt-6">
                        <div class="card bg-white rounded-xl shadow-md p-6">
                            <div class="flex items-center mb-4">
                                <div class="bg-red-100 p-3 rounded-full">
                                    <i class="fas fa-clipboard-list text-red-600 text-xl"></i>
                                </div>
                                <h2 class="text-lg font-semibold mr-3">وضعیت سفارش‌ها</h2>
                            </div>

                            <div id="no-orders-message" class="hidden bg-yellow-50 text-yellow-800 p-4 rounded-lg mb-4">
                                <i class="fas fa-exclamation-triangle ml-2"></i>
                                <span id="no-orders-text">بر اساس فیلتر انتخاب شده، هیچ سفارشی وجود ندارد.</span>
                            </div>

                            <div class="chart-container">
                                <canvas id="orderStatusChart"></canvas>
                            </div>

                            <div class="mt-4 grid grid-cols-2 gap-3" id="order-statuses">

                        </div>
                        </div>
                    </div>
                    <div class="mt-6">
                        <div class="card bg-white rounded-xl shadow-md p-6">
                            <div class="flex items-center mb-4">
                                <div class="bg-orange-100 p-3 rounded-full">
                                    <i class="fas fa-credit-card text-orange-600 text-xl"></i>
                                </div>
                                <h2 class="text-lg font-semibold mr-3">وضعیت پرداخت‌ها</h2>
                            </div>

                            <div class="mt-4 grid grid-cols-2 gap-3" id="payment-statuses">
                                <div class="flex items-center gap-4 p-3 bg-yellow-400 bg-opacity-10 rounded-lg">
                                    <div class="w-3 h-3 rounded-full bg-yellow-400"></div>
                                    <span class="text-gray-700 font-medium">در انتظار پرداخت</span>
                                    <span class="text-gray-900 font-bold mr-auto"></span>
                                </div>
                                <div class="flex items-center gap-4 p-3 bg-green-400 bg-opacity-10 rounded-lg">
                                    <div class="w-3 h-3 rounded-full bg-green-400"></div>
                                    <span class="text-gray-700 font-medium">پرداخت شده</span>
                                    <span class="text-gray-900 font-bold mr-auto"></span>
                                </div>
                                <div class="flex items-center gap-4 p-3 bg-red-400 bg-opacity-10 rounded-lg">
                                    <div class="w-3 h-3 rounded-full bg-red-400"></div>
                                    <span class="text-gray-700 font-medium">شکست خورده</span>
                                    <span class="text-gray-900 font-bold mr-auto"></span>
                                </div>
                            </div>
                        </div>
                    </div>
    </main>
</div>

</div>

<?php include('include/footer_admin.php')?>

<?php include('include/main_admin.php')?>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

<style>
  .accent-bg { 
    background: linear-gradient(135deg, rgba(242, 194, 42, 0.06) 0%, rgba(31, 125, 59, 0.02) 100%);
  }
  .table-shadow { 
    box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1),
                0 10px 10px -5px rgba(0,0,0,0.04);
  }
  .sidebar-overlay {
    position: fixed;
    inset: 0;
    background-color: rgba(0,0,0,0.5);
    display: none;
    z-index: 40;
  }
</style>

<div class="sidebar-overlay"></div>

<div class="dashboard-container" dir="rtl">
<?php include('include/header_admin.php')?>    

<div class="main-content">

    <!-- Page Title -->
    <header class="top-nav">
                <div style="display: flex; align-items: center;">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
                        </svg>
                    </button>
                    <h1 class="page-title">افزودن تأمین‌کننده جدید</h1>
                </div>
                <div class="top-nav-actions">
                    <div class="search-box">
                        <input type="text" class="search-input" placeholder="جستجوی قطعات، کد قطعه، خودرو...">
                        <svg class="search-icon" viewBox="0 0 24 24">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                        </svg>
                    </div>
                    <button class="notification-btn" onclick="showNotification('شما ۵ اعلان جدید دارید', 'info')">
                        <svg class="notification-icon" viewBox="0 0 24 24">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                        <div class="notification-badge">۵</div>
                    </button>
                </div>
            </header>

    <!-- Form -->
    <main class="dashboard-content p-4 accent-bg min-h-screen">
        <div class="bg-white p-6 rounded-2xl table-shadow">

            <form action="" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">

                <div>
                    <label class="block text-sm font-semibold mb-1">نام تأمین‌کننده:</label>
                    <input type="text" name="name"
                           class="w-full border px-3 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600"
                           placeholder="مثال: علی جمشیدی" required>
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-1">شماره تماس:</label>
                    <input type="text" name="phone"
                           class="w-full border px-3 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600"
                           placeholder="0912XXXXXXX">
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-1">نام شرکت:</label>
                    <input type="text" name="company"
                           class="w-full border px-3 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600"
                           placeholder="مثال: قطعه سازان شرق">
                </div>

                <div>
                    <label class="block text-sm font-semibold mb-1">ایمیل:</label>
                    <input type="email" name="email"
                           class="w-full border px-3 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600"
                           placeholder="example@mail.com">
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-semibold mb-1">آدرس:</label>
                    <textarea name="address" rows="3"
                              class="w-full border px-3 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600"
                              placeholder="آدرس دقیق تامین‌کننده"></textarea>
                </div>

                <div class="md:col-span-2 flex justify-end mt-4 gap-3">
                    <a href="suppliers.php"
                       class="px-6 py-3 bg-gray-300 hover:bg-gray-400 text-gray-800 font-medium rounded-xl transition">
                        بازگشت
                    </a>
                    <button type="submit"
                            class="px-6 py-3 bg-green-700 hover:bg-green-800 text-white font-medium rounded-xl shadow-md transition">
                        ثبت تأمین‌کننده
                    </button>
                </div>
            </form>

        </div>
    </main>

</div>
</div>

<?php include('include/footer_admin.php')?>
